# Crescent App

App Flutter para análisis y compra/venta de acciones.